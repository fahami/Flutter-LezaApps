import 'package:flutter/material.dart';

var colorCard = Color(0xFFEEEEEE);
var colorHighlightTitle = Color(0xFF232A32);
var colorHighlightMore = Color(0xFFF2BA1F);
var colorAccent = Colors.amber;
