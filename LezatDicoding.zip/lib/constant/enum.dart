enum ResultState { Loading, NoData, HasData, Error }
